/**
 * popup/popup.js — Extension Popup Logic
 * ========================================
 * Reads state from background service worker and renders UI.
 * Handles token setup / removal.
 */

"use strict";

// ── Elements ──────────────────────────────────────────────────
const statusCard    = document.getElementById("status-card");
const statusDot     = document.getElementById("status-dot");
const statusText    = document.getElementById("status-text");
const infoSection   = document.getElementById("info-section");
const attId         = document.getElementById("att-id");
const trackingBadge = document.getElementById("tracking-badge");
const currentUrl    = document.getElementById("current-url");
const nativeDot     = document.getElementById("native-dot");
const nativeText    = document.getElementById("native-text");
const tokenSetup    = document.getElementById("token-setup");
const tokenActions  = document.getElementById("token-actions");
const tokenInput    = document.getElementById("token-input");
const saveTokenBtn  = document.getElementById("save-token-btn");
const clearTokenBtn = document.getElementById("clear-token-btn");


// ── Load state from background ────────────────────────────────
chrome.runtime.sendMessage({ type: "get_state" }, (response) => {
    if (chrome.runtime.lastError || !response) {
        renderError("Extension not loaded. Try reloading.");
        return;
    }

    renderState(response);
});

// ── Get current tab URL ───────────────────────────────────────
chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (tabs[0] && tabs[0].url) {
        let url = tabs[0].url;
        if (url.startsWith("chrome://") || url.startsWith("moz-extension://")) {
            url = "Browser internal page";
        }
        currentUrl.textContent = url;
        currentUrl.title       = url;
    }
});


// ── Render functions ──────────────────────────────────────────
function renderState(response) {
    const { state, has_token, native_connected } = response;

    // Native host status
    if (native_connected) {
        nativeDot.className  = "dot";
        nativeDot.style.background = "#10B981";
        nativeText.textContent = "Desktop agent: connected ✓";
    } else {
        nativeDot.style.background = "#9CA3AF";
        nativeText.textContent = "Desktop agent: not connected (fallback mode)";
    }

    // Token setup vs actions
    if (!has_token) {
        tokenSetup.style.display   = "block";
        tokenActions.style.display = "none";
        renderNoToken();
        return;
    }

    tokenSetup.style.display   = "none";
    tokenActions.style.display = "block";

    // State-based UI
    if (!state.checked_in) {
        renderIdle(state.state === "checked_out" ? "Checked out" : "Not checked in");
    } else if (state.on_break) {
        renderBreak();
    } else {
        renderWorking(state);
    }
}

function renderWorking(state) {
    statusCard.className   = "status-card working";
    statusDot.className    = "dot green";
    statusText.textContent = "Tracking active — working";
    infoSection.style.display = "block";

    attId.textContent = state.attendance_id || "—";
    trackingBadge.className   = "badge badge-green";
    trackingBadge.textContent = "Active";
}

function renderBreak() {
    statusCard.className   = "status-card break";
    statusDot.className    = "dot amber";
    statusText.textContent = "On break — tracking paused";
    infoSection.style.display = "block";
    trackingBadge.className   = "badge badge-amber";
    trackingBadge.textContent = "Paused (break)";
}

function renderIdle(reason) {
    statusCard.className   = "status-card idle";
    statusDot.className    = "dot gray";
    statusText.textContent = reason || "Not checked in";
    infoSection.style.display = "none";
}

function renderNoToken() {
    statusCard.className   = "status-card no-token";
    statusDot.className    = "dot red";
    statusText.textContent = "Token not set — paste your token below";
    infoSection.style.display = "none";
}

function renderError(msg) {
    statusCard.className   = "status-card no-token";
    statusDot.className    = "dot red";
    statusText.textContent = msg;
}


// ── Token actions ─────────────────────────────────────────────
saveTokenBtn.addEventListener("click", () => {
    const token = tokenInput.value.trim();
    if (!token || token.length < 32) {
        tokenInput.style.borderColor = "#EF4444";
        return;
    }
    tokenInput.style.borderColor = "";
    saveTokenBtn.textContent     = "Saving...";
    saveTokenBtn.disabled        = true;

    chrome.runtime.sendMessage({ type: "save_token", token }, (resp) => {
        if (resp && resp.ok) {
            saveTokenBtn.textContent = "✓ Saved!";
            setTimeout(() => window.close(), 800);
        } else {
            saveTokenBtn.textContent = "Save Token";
            saveTokenBtn.disabled    = false;
        }
    });
});

clearTokenBtn.addEventListener("click", () => {
    if (!confirm("Remove token? Extension will stop tracking until a new token is added.")) return;
    chrome.runtime.sendMessage({ type: "clear_token" }, () => {
        window.close();
    });
});
