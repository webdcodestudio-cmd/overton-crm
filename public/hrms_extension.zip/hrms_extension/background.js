/**
 * background.js — HRMS Extension Service Worker
 * ================================================
 * Tracks active browser tab URL and sends to:
 *   1. Desktop agent via Native Messaging (primary)
 *   2. HRMS server directly via fetch (fallback if agent offline)
 *
 * Only sends data when:
 *   - Employee is checked in (status = "working")
 *   - Not on break (on_break = false)
 *   - URL is not in blacklist
 *
 * Status polling: every 30s to /agent/status.php
 * URL batch send: every 10s
 */

// ── Config ────────────────────────────────────────────────────
const HRMS_BASE_URL    = "https://hrms.dcode-tech.in";
const STATUS_ENDPOINT  = `${HRMS_BASE_URL}/agent/status.php`;
const FALLBACK_ENDPOINT= `${HRMS_BASE_URL}/agent/heartbeat.php`;
const STATUS_POLL_MS   = 30000;   // 30s
const SEND_INTERVAL_MS = 10000;   // 10s
const NATIVE_HOST      = "com.hrms.agent";  // must match native host registration

// ── State ─────────────────────────────────────────────────────
let agentState = {
    checked_in:    false,
    on_break:      false,
    attendance_id: null,
    state:         "not_checked_in",
};

let currentVisit = {
    url:       null,
    title:     null,
    domain:    null,
    startTime: null,
};

let agentToken      = null;   // Bearer token from storage
let nativePort      = null;   // Native messaging port (to desktop agent)
let pollTimer       = null;
let sendTimer       = null;


// ── Init ──────────────────────────────────────────────────────
async function init() {
    // Load token from storage
    const stored = await chrome.storage.local.get(["agent_token"]);
    agentToken = stored.agent_token || null;

    if (!agentToken) {
        console.log("[HRMS] No token stored. User needs to configure extension.");
        updateIcon("gray");
        return;
    }

    // Try to connect to native messaging host (desktop agent)
    connectNative();

    // Start polling attendance status
    pollStatus();
    pollTimer = setInterval(pollStatus, STATUS_POLL_MS);

    // Start sending URL batches
    sendTimer = setInterval(sendCurrentVisit, SEND_INTERVAL_MS);

    // Listen for tab changes
    chrome.tabs.onActivated.addListener(onTabActivated);
    chrome.tabs.onUpdated.addListener(onTabUpdated);
    chrome.windows.onFocusChanged.addListener(onWindowFocus);

    console.log("[HRMS] Extension initialized, token loaded.");
}


// ── Native Messaging ──────────────────────────────────────────
function connectNative() {
    try {
        nativePort = chrome.runtime.connectNative(NATIVE_HOST);
        nativePort.onMessage.addListener((msg) => {
            // Agent can push state updates via native messaging
            if (msg.type === "state_update") {
                updateState(msg);
            }
        });
        nativePort.onDisconnect.addListener(() => {
            console.log("[HRMS] Native host disconnected — using direct API fallback");
            nativePort = null;
        });
        console.log("[HRMS] Connected to native host");
    } catch (e) {
        console.log("[HRMS] Native host not available — will use direct API");
        nativePort = null;
    }
}


// ── Status Polling ────────────────────────────────────────────
async function pollStatus() {
    if (!agentToken) return;

    try {
        const resp = await fetch(STATUS_ENDPOINT, {
            headers: { "Authorization": `Bearer ${agentToken}` },
            signal: AbortSignal.timeout(8000),
        });

        if (!resp.ok) {
            if (resp.status === 401 || resp.status === 403) {
                console.warn("[HRMS] Token invalid — clearing");
                await chrome.storage.local.remove(["agent_token"]);
                agentToken = null;
                updateIcon("gray");
            }
            return;
        }

        const data = await resp.json();
        if (data.success) {
            updateState(data);
        }
    } catch (e) {
        // Network error — keep last known state
        console.debug("[HRMS] Status poll failed:", e.message);
    }
}

function updateState(data) {
    const wasTracking = agentState.checked_in && !agentState.on_break;

    agentState.checked_in    = data.checked_in    ?? agentState.checked_in;
    agentState.on_break       = data.on_break      ?? agentState.on_break;
    agentState.attendance_id  = data.attendance_id ?? agentState.attendance_id;
    agentState.state          = data.state         ?? agentState.state;

    const nowTracking = agentState.checked_in && !agentState.on_break;

    // Update icon
    if (!agentState.checked_in) {
        updateIcon("gray");
    } else if (agentState.on_break) {
        updateIcon("amber");
    } else {
        updateIcon("green");
    }

    // State changed to not tracking — save current visit
    if (wasTracking && !nowTracking) {
        sendCurrentVisit();
        currentVisit = { url: null, title: null, domain: null, startTime: null };
    }
}


// ── Tab Tracking ──────────────────────────────────────────────
async function onTabActivated(activeInfo) {
    if (!agentState.checked_in || agentState.on_break) return;

    try {
        const tab = await chrome.tabs.get(activeInfo.tabId);
        handleTabChange(tab);
    } catch (e) { /* tab may have closed */ }
}

function onTabUpdated(tabId, changeInfo, tab) {
    if (!agentState.checked_in || agentState.on_break) return;
    if (changeInfo.status !== "complete") return;

    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs[0] && tabs[0].id === tabId) {
            handleTabChange(tabs[0]);
        }
    });
}

function onWindowFocus(windowId) {
    if (windowId === chrome.windows.WINDOW_ID_NONE) return;
    chrome.tabs.query({ active: true, windowId }, (tabs) => {
        if (tabs[0]) handleTabChange(tabs[0]);
    });
}

function handleTabChange(tab) {
    if (!tab || !tab.url) return;

    // Skip chrome:// and extension pages
    if (tab.url.startsWith("chrome://") ||
        tab.url.startsWith("chrome-extension://") ||
        tab.url.startsWith("moz-extension://") ||
        tab.url.startsWith("about:") ||
        tab.url.startsWith("edge://")) {
        return;
    }

    const newUrl    = tab.url;
    const newTitle  = tab.title || "";
    const newDomain = extractDomain(newUrl);

    // If same URL, just update title
    if (newUrl === currentVisit.url) {
        currentVisit.title = newTitle;
        return;
    }

    // Save previous visit before switching
    if (currentVisit.url && currentVisit.startTime) {
        sendCurrentVisit();
    }

    // Start new visit
    currentVisit = {
        url:       newUrl,
        title:     newTitle,
        domain:    newDomain,
        startTime: Date.now(),
    };

    // Send URL to native host immediately (so agent can include in heartbeat)
    if (nativePort) {
        try {
            nativePort.postMessage({
                type:   "url_update",
                url:    newUrl,
                title:  newTitle,
                domain: newDomain,
            });
        } catch (e) {
            nativePort = null;
        }
    }
}


// ── Send Visit Data ───────────────────────────────────────────
async function sendCurrentVisit() {
    if (!agentState.checked_in || agentState.on_break) return;
    if (!currentVisit.url || !currentVisit.startTime) return;
    if (!agentToken || !agentState.attendance_id) return;

    const duration = Math.round((Date.now() - currentVisit.startTime) / 1000);

    // Minimum 3 seconds to count as a visit
    if (duration < 3) return;

    const payload = {
        attendance_id:    agentState.attendance_id,
        app_name:         "Browser",
        window_title:     currentVisit.title || currentVisit.domain,
        active_url:       currentVisit.url,
        duration_seconds: Math.min(duration, 300),  // cap 5 min
        is_idle:          false,
        os_type:          "unknown",   // agent knows OS, extension doesn't
    };

    // Reset visit timer (keep tracking same URL from now)
    currentVisit.startTime = Date.now();

    // Try native host first (agent batches it)
    if (nativePort) {
        try {
            nativePort.postMessage({ type: "url_visit", payload });
            return;
        } catch (e) {
            nativePort = null;
        }
    }

    // Fallback: send directly to HRMS heartbeat endpoint
    try {
        await fetch(FALLBACK_ENDPOINT, {
            method:  "POST",
            headers: {
                "Authorization": `Bearer ${agentToken}`,
                "Content-Type":  "application/json",
            },
            body: JSON.stringify(payload),
            signal: AbortSignal.timeout(8000),
        });
    } catch (e) {
        console.debug("[HRMS] URL send fallback failed:", e.message);
    }
}


// ── Icon helpers ──────────────────────────────────────────────
function updateIcon(color) {
    const icons = {
        green: { "16": "icons/icon16_green.png",  "32": "icons/icon32_green.png"  },
        amber: { "16": "icons/icon16_amber.png",  "32": "icons/icon32_amber.png"  },
        gray:  { "16": "icons/icon16.png",        "32": "icons/icon32.png"        },
    };
    chrome.action.setIcon({ path: icons[color] || icons.gray });

    const titles = {
        green: "HRMS — Tracking active",
        amber: "HRMS — On break (paused)",
        gray:  "HRMS — Not checked in",
    };
    chrome.action.setTitle({ title: titles[color] || "HRMS Activity Tracker" });
}

function extractDomain(url) {
    try {
        return new URL(url).hostname.replace(/^www\./, "");
    } catch {
        return url;
    }
}


// ── Message handler (from popup / content script) ─────────────
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.type === "get_state") {
        sendResponse({
            state:         agentState,
            has_token:     !!agentToken,
            native_connected: !!nativePort,
        });
        return true;
    }

    if (msg.type === "save_token") {
        agentToken = msg.token;
        chrome.storage.local.set({ agent_token: msg.token });
        init();  // Re-init with new token
        sendResponse({ ok: true });
        return true;
    }

    if (msg.type === "clear_token") {
        agentToken = null;
        chrome.storage.local.remove(["agent_token"]);
        updateIcon("gray");
        sendResponse({ ok: true });
        return true;
    }
});


// ── Start ─────────────────────────────────────────────────────
init();
