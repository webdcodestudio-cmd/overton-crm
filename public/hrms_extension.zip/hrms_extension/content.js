/**
 * content.js — HRMS Extension Content Script
 * ============================================
 * Runs on every webpage.
 * Sends page title updates to background service worker.
 * Also handles SPA (Single Page Apps) where URL changes
 * without a full page reload (React, Vue, Angular apps).
 */

(function () {
    "use strict";

    let lastUrl   = location.href;
    let lastTitle = document.title;

    // Notify background of current page on load
    notifyBackground();

    // Watch for SPA URL changes (history.pushState / replaceState)
    const _pushState    = history.pushState.bind(history);
    const _replaceState = history.replaceState.bind(history);

    history.pushState = function (...args) {
        _pushState(...args);
        onUrlChange();
    };
    history.replaceState = function (...args) {
        _replaceState(...args);
        onUrlChange();
    };

    window.addEventListener("popstate", onUrlChange);

    // Watch for title changes (some SPAs change title after URL)
    const titleObserver = new MutationObserver(() => {
        if (document.title !== lastTitle) {
            lastTitle = document.title;
            notifyBackground();
        }
    });

    const titleEl = document.querySelector("title");
    if (titleEl) {
        titleObserver.observe(titleEl, { childList: true, subtree: true });
    }

    function onUrlChange() {
        setTimeout(() => {
            if (location.href !== lastUrl) {
                lastUrl   = location.href;
                lastTitle = document.title;
                notifyBackground();
            }
        }, 100); // Small delay for SPA to update title
    }

    function notifyBackground() {
        chrome.runtime.sendMessage({
            type:  "page_update",
            url:   location.href,
            title: document.title,
        }).catch(() => {
            // Background may be inactive — ignore
        });
    }

})();
