#!/bin/bash
# Install native messaging host on Linux
# Run ONCE after installing the extension

EXT_ID="REPLACE_WITH_YOUR_EXTENSION_ID"
AGENT_PATH="$(cd "$(dirname "$0")/.." && pwd)/HRMS_Agent"
MANIFEST="$(dirname "$0")/com.hrms.agent.json"

# Update JSON with actual values
sed -i \
    -e "s|REPLACE_WITH_FULL_PATH_TO_HRMS_Agent|$AGENT_PATH|g" \
    -e "s|REPLACE_WITH_EXTENSION_ID|$EXT_ID|g" \
    "$MANIFEST"

# Chrome/Chromium
mkdir -p "$HOME/.config/google-chrome/NativeMessagingHosts"
mkdir -p "$HOME/.config/chromium/NativeMessagingHosts"
cp "$MANIFEST" "$HOME/.config/google-chrome/NativeMessagingHosts/com.hrms.agent.json"
cp "$MANIFEST" "$HOME/.config/chromium/NativeMessagingHosts/com.hrms.agent.json"

# Firefox
mkdir -p "$HOME/.mozilla/native-messaging-hosts"
cp "$MANIFEST" "$HOME/.mozilla/native-messaging-hosts/com.hrms.agent.json"

echo "Native messaging host registered."
echo "Extension ID used: $EXT_ID"
