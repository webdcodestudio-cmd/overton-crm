@echo off
:: Install native messaging host on Windows
:: Run this ONCE after installing the extension

:: Get extension ID from chrome://extensions/
set EXT_ID=REPLACE_WITH_YOUR_EXTENSION_ID

:: Path to HRMS_Agent.exe
set AGENT_PATH=%~dp0..\HRMS_Agent.exe

:: Update the JSON with actual path
powershell -Command "(Get-Content com.hrms.agent.json) -replace 'REPLACE_WITH_FULL_PATH_TO_HRMS_Agent', '%AGENT_PATH:\=\\%' -replace 'REPLACE_WITH_EXTENSION_ID', '%EXT_ID%' | Set-Content com.hrms.agent.json"

:: Register in Windows Registry (HKCU = current user, no admin needed)
reg add "HKCU\Software\Google\Chrome\NativeMessagingHosts\com.hrms.agent" /ve /t REG_SZ /d "%~dp0com.hrms.agent.json" /f
reg add "HKCU\Software\Microsoft\Edge\NativeMessagingHosts\com.hrms.agent"   /ve /t REG_SZ /d "%~dp0com.hrms.agent.json" /f

echo Native messaging host registered for Chrome and Edge.
echo Extension ID used: %EXT_ID%
