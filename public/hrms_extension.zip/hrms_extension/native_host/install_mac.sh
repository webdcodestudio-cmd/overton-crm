#!/bin/bash
# Install native messaging host on Mac
# Run ONCE after installing the extension

EXT_ID="REPLACE_WITH_YOUR_EXTENSION_ID"
AGENT_PATH="$(cd "$(dirname "$0")/.." && pwd)/HRMS_Agent"
MANIFEST="$(dirname "$0")/com.hrms.agent.json"

# Update JSON with actual values
sed -i '' \
    -e "s|REPLACE_WITH_FULL_PATH_TO_HRMS_Agent|$AGENT_PATH|g" \
    -e "s|REPLACE_WITH_EXTENSION_ID|$EXT_ID|g" \
    "$MANIFEST"

# Install for Chrome
CHROME_DIR="$HOME/Library/Application Support/Google/Chrome/NativeMessagingHosts"
mkdir -p "$CHROME_DIR"
cp "$MANIFEST" "$CHROME_DIR/com.hrms.agent.json"

# Install for Firefox
FF_DIR="$HOME/Library/Application Support/Mozilla/NativeMessagingHosts"
mkdir -p "$FF_DIR"
cp "$MANIFEST" "$FF_DIR/com.hrms.agent.json"

echo "Native messaging host registered for Chrome and Firefox."
echo "Extension ID used: $EXT_ID"
